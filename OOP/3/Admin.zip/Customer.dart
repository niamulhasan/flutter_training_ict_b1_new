import 'User.dart';

class Customer extends User {
  String? city;

  void buy(int pid) {
    print("Buying produuct of id $pid");
  }

  void sell(int pid) {
    print("Selling product of id $pid");
  }
}
