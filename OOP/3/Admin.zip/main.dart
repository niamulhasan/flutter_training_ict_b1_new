import 'Admin.dart';

void main() {
  var admin1 = Admin();
  admin1.name = "akkas";
  admin1.password = "1234";
  admin1.email = "akkas@amail.com";
  print(admin1.login());
}
