import 'User.dart';

class Admin extends User {
  String? adminType;

  void deleteUser(int uid) {
    print("Deleting user of id $uid");
  }

  void addUser() {
    print("User created");
  }
}
